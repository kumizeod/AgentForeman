#!/usr/bin/env python3
"""Re-run the archived code and trusted verification; no Codex required."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--baseline", action="store_true")
args = parser.parse_args()
cfg = json.loads((root / "config.json").read_text())
kind = "baseline" if args.baseline else "candidate"
code = root / kind / "code"
output = root / "reproduced" / kind
output.mkdir(parents=True, exist_ok=True)
values = dict(python=sys.executable, workspace=str(code), artifacts=str(output), trusted=str(root / "trusted"))
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
for stage in ("train", "verify"):
    argv = []
    for item in cfg[stage]["command"]:
        for key, value in values.items():
            item = item.replace("{" + key + "}", value)
        argv.append(item)
    print("Running:", argv, flush=True)
    subprocess.run(argv, cwd=code if stage == "train" else root / "trusted", env=env,
                   timeout=cfg[stage]["timeout_seconds"], check=True)
print((output / "verification.json").read_text())
